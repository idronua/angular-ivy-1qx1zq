export const products = [
  {
    name: 'Caramel',
    price: 3.99,
    description: 'Sweet home-made caramel'
  },
  {
    name: 'Strawberry',
    price: 3.49,
    description: 'Own-picked summer farm strawberry'
  },
  {
    name: 'Hazelnut',
    price: 4.19,
    description: ''
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/